/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_476()
{
    return 1485258513U;
}

unsigned getval_241()
{
    return 3284633928U;
}

unsigned getval_474()
{
    return 3284633928U;
}

unsigned getval_455()
{
    return 1925273821U;
}

unsigned addval_129(unsigned x)
{
    return x + 3351742792U;
}

unsigned getval_156()
{
    return 3247476824U;
}

unsigned addval_238(unsigned x)
{
    return x + 3281031256U;
}

void setval_306(unsigned *p)
{
    *p = 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_283(unsigned *p)
{
    *p = 3383018121U;
}

unsigned addval_292(unsigned x)
{
    return x + 3682910873U;
}

void setval_435(unsigned *p)
{
    *p = 3224949133U;
}

unsigned getval_285()
{
    return 3222851209U;
}

unsigned addval_339(unsigned x)
{
    return x + 2464188744U;
}

void setval_116(unsigned *p)
{
    *p = 3372273289U;
}

void setval_438(unsigned *p)
{
    *p = 2596524457U;
}

unsigned getval_294()
{
    return 3286270280U;
}

void setval_248(unsigned *p)
{
    *p = 1321718153U;
}

unsigned getval_181()
{
    return 3286272456U;
}

unsigned addval_212(unsigned x)
{
    return x + 3352398309U;
}

unsigned addval_376(unsigned x)
{
    return x + 3523792521U;
}

unsigned getval_284()
{
    return 3676885385U;
}

unsigned addval_106(unsigned x)
{
    return x + 3767093361U;
}

void setval_232(unsigned *p)
{
    *p = 2430634313U;
}

void setval_450(unsigned *p)
{
    *p = 2497743176U;
}

void setval_242(unsigned *p)
{
    *p = 3229929097U;
}

void setval_451(unsigned *p)
{
    *p = 3676361097U;
}

unsigned addval_468(unsigned x)
{
    return x + 3523793289U;
}

unsigned getval_153()
{
    return 2447411528U;
}

void setval_278(unsigned *p)
{
    *p = 3229926057U;
}

void setval_211(unsigned *p)
{
    *p = 3523792553U;
}

void setval_166(unsigned *p)
{
    *p = 3531919017U;
}

void setval_459(unsigned *p)
{
    *p = 3525366185U;
}

unsigned getval_480()
{
    return 3524838025U;
}

unsigned getval_397()
{
    return 3221278345U;
}

unsigned getval_303()
{
    return 2496563503U;
}

unsigned addval_204(unsigned x)
{
    return x + 3525362313U;
}

unsigned addval_209(unsigned x)
{
    return x + 3229926025U;
}

unsigned getval_494()
{
    return 2430634312U;
}

unsigned getval_326()
{
    return 3281044097U;
}

void setval_227(unsigned *p)
{
    *p = 3372794497U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
